# NOCLIP — Android emulator screenshots (28 October 2026)

Developer credit: 1900xd
Google Play: https://play.google.com/store/apps/details?id=com.noclip.backrooms
Official game / press page: https://mcm190.github.io/noclip-privacy/press/

Five actual 1920 × 1080 app captures from the existing Android 1.0.5 debug package, running in a separate visible Android 35 emulator. Developer controls selected levels and camera positions. These are individual captured moments, not a continuous playthrough or physical-phone performance evidence.

Images are 24-bit RGB PNGs. Fully opaque alpha was discarded during lossless export; no resizing, cropping, retouching, added text or generated pixels. The HUD and camcorder treatment are the game itself.

01-office-key.png — Floating key in the Office, with TAKE KEY touch control.
02-office-blackout.png — Office after key pickup, flashlight and RUN objective.
03-poolrooms.png — The Poolrooms with an upper gallery.
04-hotel.png — Hotel foyer with a staircase and galleries.
05-cathedral.png — Cathedral with stained glass and an upper gallery.

The emulator copy was not installed through Google Play, so billing was unavailable during capture. All levels can unlock through ordinary play; an optional purchase unlocks them immediately.

Supplied for editorial coverage of NOCLIP. Credit 1900xd. Gameplay footage and in-game audio are cleared for recording, streaming and short clips.
