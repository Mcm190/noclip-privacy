# NOCLIP press kit v2 (27 October 2026)

- `press-factsheet.md`: facts, store link, clearance and credit (1900xd)
- `android-device/`: 9 stills from a real Android phone recording (title screen and Level 14, The Cathedral)
- `desktop-captures/`: 5 desktop-build stills (Office key, Hotel foyer, Poolrooms, Cathedral, blackout)
- `icon-512.png`: store icon

All images are unedited game captures, re-encoded as JPEG. Store: https://play.google.com/store/apps/details?id=com.noclip.backrooms
